A working example with custom form controls and reusable nested form groups.
Uses the control value accessor and validator interfaces. 

[Learn more...](https://javascript.plainenglish.io/angular-custom-form-controls-nested-form-groups-made-easy-2ac09e91cf67)

[StackBlitz link](https://stackblitz.com/edit/custom-form-controls-demo?file=src/app/app.component.ts)
